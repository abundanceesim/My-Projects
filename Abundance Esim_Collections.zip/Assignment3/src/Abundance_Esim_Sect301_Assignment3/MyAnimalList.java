package Abundance_Esim_Sect301_Assignment3;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Collections;
import java.util.Collection;
import java.util.Set;
import java.util.HashSet; 
/**
 * Filename: MyAnimalList.java
 * Project: Assignment03
 * Description: This class demonstrates and implements the use of collections and Collections interface methods to organize and manipulate data using several methods from the 
 * Collection interface. It does so by making use of Collections types like lists, linked lists and sets. 
 * @author Abundance Esim
 *
 */ 
public class MyAnimalList {  
	/**
	 * method main contains the arrays, lists and set which would be used in this class.
	 * @param args
	 */
public static void main(String[] args) {

   // add animals to list1
	/**
	 * String array of animals
	 */
   String[] animals = {"dog", "cat", "lion", "eagle", "monkey", "elephant"};
   
   /**
    * animals array is converted first into a list, and then into a linked list. All the items from the array are added to the list "list1". This is done in order to 
    * be able to manipulate the list items using the Collections interface methods.
    */
   List<String> listA= Arrays.asList(animals);
   LinkedList<String> list1 = new LinkedList<String>(listA);
   
   /**
    * Second string array of animals
    */
   String[] animals2 = {"cow", "dolphin", "zebra", "dog", "goat", "snake"};
   
   
   /**
    * animals2 array is converted first into a list, and then into a linked list. All the items from the array are added to the list "list2". This is done in order to 
    * be able to manipulate the list items using the Collections interface methods.
    */
   List<String> listB= Arrays.asList(animals2);
   LinkedList<String> list2 = new LinkedList<String>(listB);
 

   /**
    * The two lists are combined for easy manipulation. Items from list2 are put into list1 using the addAll() method. Because all the items from list2 have been 
    * transferred, resources which were being used by list2 are now released by making list2 null.
    */
   list1.addAll(list2);
   list2 = null;
   /**
    * printList() method is called to print list1 each time it has been modified.
    */
   printList(list1);
   
   /**
    * all [lowercase]items from list1 which is a linked list containing strings, are converted to upper case using the methods replaceAll(), which substitutes the value
    * of every item in the list, and toUpperCase(), which changes strings to uppercase.
    */
   list1.replaceAll(String:: toUpperCase);
   System.out.printf("%nDisplaying names of animals in uppercase letters...%n");
   printList(list1);
   
   /**
    * A sublist is created from list1 for list items from position 4 to 6. This allows for the use of clear() method to remove all the items from the sublist and by
    * extension, those items would be removed from list1. The new list is printed out using printList() method.
    */
   List<String> subList = list1.subList(4, 7);
   subList.clear();
   System.out.printf("%nDeleting animals 4 to 6...%n");
   printList(list1);

  /**
   * current state of list1 is redisplayed using the printList() method.
   */
   System.out.printf("%nHere is the current list of animals...%n");
   printList(list1);
  
   /**
    * printReversedList() method is called. This method uses the Collections interface's reverse() method to reverse the order of the items in list1.
    */
   System.out.printf("%nReversed list:%n");
   printReversedList(list1);
   
   /**
    * Items from list1 are sorted in alphabetical(and also ascending) order using the method sort() from the Collections interface.
    * printList() method is called to print the sorted list.
    */
   System.out.printf("%nSorted animals in alphabetical order...%n");
   Collections.sort(list1);
   printList(list1);

   /**
    * This demonstrates the ability of sets to eliminate duplicate items using the method printNonDuplicates().
    */
   System.out.printf("%nRemoving duplicate animals...%n");
   /**
    * printNonDuplicates() method is called and this prints out the items from the list without duplicating any one.
    */
   printNonDuplicates(list1);
}

/**
 * This method prints out items from the list without including duplicates. It does so by converting the list into a set. It then prints out the hash set and no
 * duplicates are found, only unique items are displayed.
 * The method is made static in order to enable it to be accessed by the main method which is also static.
 * @param list the list which does not contain any duplicate values.
 */
public static void printNonDuplicates(LinkedList<String> list) {
	   Set<String> hashSet = new HashSet<String>(list);
	   hashSet.addAll(list);
	   System.out.println("List is:");
	   System.out.println(hashSet);
}


/**
 * This method demonstrates the use of the Collections interface method reverse() which reverses the order of items in a collection. After reversing the order, this
 * method prints the list. 
 * The method is made static in order to enable it to be accessed by the main method which is also static.
 * @param list the [reversed] list to be printed.
 */
public static void printReversedList(LinkedList<String> list) {
	Collections.reverse(list);
	printList(list);
}

/**
 * printList() method would be called to print the linked list "list1". It would be called after each modification to the list has been made in order to 
 * demonstrate the changes made.
 * The method is made static in order to enable it to be accessed by the main method which is also static.
 * @param list the [modified] list to be printed. 
 */
public static void printList(LinkedList<String> list) {
	System.out.println("List is:");
	System.out.println(list);
	
} 


}

