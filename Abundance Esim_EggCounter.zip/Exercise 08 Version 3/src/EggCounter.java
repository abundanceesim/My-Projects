/*
 * Project by Abundance Esim
 * CST8116 Section 311 
 * Lab Exercise 08 Version 3
 */
//Java's Scanner class imported to read user inputs
import java.util.Scanner;

/*
 * EggCounter class counts eggs in each size category based on user's input for egg weight
 * 
 */
public class EggCounter { 
	Scanner input = new Scanner(System.in);
	private static final int SIZE = 8;
	private static final int[] eggCounts = new int[SIZE];
	private static final String[] eggSizeNames = {"too small", "peewee", "small", "medium", "large", "extra-large", "jumbo", "too large"};
	private static final int TOO_SMALL = 0;
	private static final int PEEWEE = 1;
	private static final int SMALL = 2;
	private static final int MEDIUM = 3;
	private static final int LARGE = 4;
	private static final int EXTRA_LARGE = 5;
	private static final int JUMBO = 6;
	private static final int TOO_LARGE = 7;
	/*
	 * contains a loop that accepts user's input for egg weight
	 *  multiple times till they exit loop using sentinel value.
	 */
	public void enterEggs() {
		String shouldContinue;
		double weight;
		int size;
		
		do {
			System.out.println("Enter egg weight:");
			weight = input.nextDouble();
			input.nextLine();
			size = sizeEgg(weight);
			eggCounts[size] = eggCounts[size] + 1;
			System.out.println("Enter another egg weight? (Y/N)");
			shouldContinue = input.nextLine();
		} while(shouldContinue.equalsIgnoreCase("Y"));
		
	}
	/*
	 * prints egg size and number of eggs in each size category
	 * an asterisk (*) is used to represent the number of eggs on a bar chart
	 */
	public void printReport() {
	    for(int index = 0; index < SIZE; index++) {
	    	for(int count = 1; count <= eggCounts[index]; count++) {
	    		System.out.print("*");
	    	}
	    	System.out.printf(" (%s: %d)%n", eggSizeNames[index], eggCounts[index]);
	    	index = index++;
	    }
	} 
	/*
	 * Decides the egg size based on weight and returns the size.
	 * magic numbers replaced with constants
	 */
	private int sizeEgg(double weight) {
		int size;
		if (weight < 15) {
			size = TOO_SMALL;
		}
		else if (weight < 18) {
			size = PEEWEE;
		}
		else if (weight < 21) {
			size = SMALL;
		}	
		else if (weight < 24) {
			size = MEDIUM;
		}
		else if (weight < 27) {
			size = LARGE;
		}
		else if (weight < 30) {
			size = EXTRA_LARGE;
		}
		else if (weight < 33) {
			size = JUMBO;
		}
		else {
			size = TOO_LARGE;
		}
		return size;
	}
}
