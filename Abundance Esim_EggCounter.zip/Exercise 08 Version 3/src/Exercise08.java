/*
 * Project by Abundance Esim
 * CST8116 Section 311 
 * Lab Exercise 08 Version 3
 */

/*
 * Driver class calculates egg size and generates report
 */
public class Exercise08 {
	/*
	 * Entry point for the application
	 */
	public static void main(String[] args) {
		System.out.println("Exercise 08 (21S) Version 3");
		EggCounter counter = new EggCounter();
		counter.enterEggs();
		counter.printReport();
		System.out.println("Program by Abundance Esim");
	}

}
