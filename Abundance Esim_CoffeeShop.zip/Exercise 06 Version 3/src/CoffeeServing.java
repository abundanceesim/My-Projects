/*
 * Project by Abundance Esim
 * CST8116 Section 311 
 * Lab Exercise 06 Version 3
 */
public class CoffeeServing { //CoffeeServing class gets the size of coffee, calculates the price and generates a report
	private int size;		//private variable for size, can only be accessed by the current class
	//public static constants introduced that represent the three coffee sizes. can be accessed by driver class
	public static final int SMALL = 1;
	public static final int MEDIUM = 2;
	public static final int LARGE = 3;
	
	//no parameter constructor initializing the size of coffee
	public CoffeeServing() {
		this(2);			//medium is the most common size bought by customers
	}
	
	//constructor with parameter for the size of the coffee
	public CoffeeServing(int size) {
		this.size = size;
		return;
	}	
	
	/*
	 * public accessor that gets coffee size. Can be used by this class or other classes.
	 */
	public int getSize() {
		return size;
	}
	/*
	 * public mutator for size, with parameter which sets coffee size to integer
	 */
	public void setSize(int size) {
		this.size = size;
	}
	/*
	 * this method calculates the price based on the size chosen and returns the price as a double
	 * the method can be used by other classes
	 * constants are used to represent size in place of magic numbers
	 */
	public double calculatePrice() {
		double price;
		
		switch(size) {
			case SMALL:
				price = 3.25;
				break;
		
			case MEDIUM:
				price = 4.50;
				break;
		
			case LARGE:
				price = 6.00;
				break;
			default:
				price = -1;
		}
		//coffee price is returned to the driver program
		return price;	
	}
	
	/*
	 * this generates a report with the size and price of the coffee. 
	 * it can be used by other classes
	 */
	public String createReport() {
		String report;
		double price;
		
		price = calculatePrice();
		
		switch(size) {
			case SMALL: 
				report = "small coffee $";
				break;
		
			case MEDIUM: 
				report = "medium coffee $";
				break;
		
			case LARGE:
				report = "large coffee $";
				break;
			default:
				report = "invalid size selected $";
		}
		
		//displays the report and price of coffee
		System.out.printf("%s%.2f \n", report, price);
		
		//the report is returned to the main program
		return report;
	}
}
