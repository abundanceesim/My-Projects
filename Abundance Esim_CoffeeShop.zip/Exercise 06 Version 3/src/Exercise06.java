/*
 * Project by Abundance Esim
 * CST8116 Section 311 
 * Lab Exercise 06 Version 3
 */
import java.util.Scanner;	//importing java's Scanner utility so that it can be used in the class
public class Exercise06 {	//Driver class where the main program runs
	//method main, program execution begins here
	public static void main(String[] args) {
		//coffee object is created from the CoffeeServing class
		CoffeeServing coffee;
		int coffeeSize; 	//variable for the size of the copy
		String report;		//variable for the report
		String shouldContinue; //this variable determines the number of times the program will run
		
		//Scanner is instantiated using the "keyboard" object 
		Scanner keyboard = new Scanner(System.in);
		
		//do-while loop created
		do {
			//displays messages welcoming user to the program and asking the user to choose from the options provided
			System.out.println("Welcome to Make Coffee Version 3");
			System.out.println("enter coffee size:");
			System.out.println(CoffeeServing.SMALL + " for Small");
			System.out.println(CoffeeServing.MEDIUM + " for Medium");
			System.out.println(CoffeeServing.LARGE + " for Large");
		
		
			//coffeeSize is used to accept the user's input
			coffeeSize = keyboard.nextInt();
		
			//CoffeeServing is instantiated by the coffee object
			coffee = new CoffeeServing();
			coffee.getSize();
			//sets the coffee size
			coffee.setSize(coffeeSize);
		
			//report uses createReport() method from CoffeeServing class(the method can be accessed because it was made public)
			report = coffee.createReport();
		
			//message prompts user to either make another order or exit the program
			System.out.println("Is there another order? (Y/N)");
			shouldContinue = keyboard.next();
		} while (shouldContinue.equalsIgnoreCase("Y")); //condition set for the loop
			
		
		//displays message with Student Name
		System.out.println("Program by Abundance Esim");
		
	}
}
