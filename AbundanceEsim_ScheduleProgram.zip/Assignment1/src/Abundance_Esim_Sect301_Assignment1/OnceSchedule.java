package Abundance_Esim_Sect301_Assignment1;

/**
 * Project: Assignment 1
 * Description: This class contains instantiates an object with a description for an activity that occurs once in a while.
 * @author Abundance Esim
 */
public class OnceSchedule extends Schedule
{
	/**
	 * OnceSchedule constructor for description of activities that occur once in a while.
	 * @param description the description of the activity.
	 */
   public OnceSchedule(String description) {
	   super(description);
   }

    /**
     * Overridden method for date. Method is run polymorphically for each object of every class in the inheritance hierarchy for superclass Schedule.
     * Method will return true if argument for date matches specified date that an activity is supposed to happen. Otherwise, it will return false.
     */
   	@Override
	public Boolean dueOn(int year, int month, int day) {
		if (year == 2021 && month == 12 && day == 7) {
			return true;
		}	   
		else {
			return false; 
		}
	}		   

}
