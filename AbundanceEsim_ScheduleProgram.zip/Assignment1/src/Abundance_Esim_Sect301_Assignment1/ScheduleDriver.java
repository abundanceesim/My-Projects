package Abundance_Esim_Sect301_Assignment1;

/**
 * Project: Assignment 1
 * Description: ScheduleDriver class containing main method for PerDaySchedule. This class runs a series of tests on Schedule class and PerDaySchedule
 * class.
 * @author Abundance Esim
 */
public class ScheduleDriver {

	public static void main(String[] args) {
		/**
		 * Schedule class instantiated using PerDaySchedule object with one argument constructor for the description of the daily activity.
		 */
	   Schedule day1 = new PerDaySchedule("change the gear oil for the aircraft");

	   /**
		 * References to classes created. These will be used with Java's reflection API methods to provide information on the various classes.
		 */
	   Class schedule = Schedule.class;
	   Class perDay = PerDaySchedule.class;
	   
	   /**
	    * Tests performed using Java's reference API. Information is provided about superclass and subclass
	    * Expected outputs and actual outputs are displayed.
	    */
	   /**
	    * Tests if subclass PerDaySchedule is a subclass of class Schedule.
	    */
	   System.out.print("PerDaySchedule is just a subclass of Schedule: ");
	   System.out.println(perDay.getSuperclass() == schedule);
	   System.out.println("Expected: true"); 
	   
	   /**
	    * Checks for any extra fields in subclass. If the number of declared fields in superclass is equal to or more than the number in subclass,
	    * subclass does not contain any extra fields.
	    */
	   System.out.print("PerDaySchedule activities have no extra fields: ");
	   System.out.println((schedule.getDeclaredFields().length >= perDay.getDeclaredFields().length));
	   System.out.println("Expected: true");  
	   
	   /**
	    * Checks schedule for daily activities and displays them using PerDaySchedule's dueOn() method. 
	    */
	   System.out.print("Looking at perday schedules: ");
	   System.out.println(day1.toString());
	   System.out.println("Expected: change the gear oil for the aircraft");
	   System.out.println(day1.dueOn(2022, 11, 12));
	   System.out.println("Expected: true");  
	}
}
