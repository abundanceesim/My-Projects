package Abundance_Esim_Sect301_Assignment1;
/**
 * imports java's Scanner utility.
 */
import java.util.Scanner;

/**
 * Project: Assignment 1
 * ScheduleAllTest class.
 * Description: This class displays schedules based on user's input for activities that occur daily, monthly or once in a while.
 * @author Abundance Esim
 *
 */
public class ScheduleAllTest
{
   public static void main(String[] args)
   {
	   /**
	    * Scanner instantiated using "console" object.
	    */
      Scanner console = new Scanner(System.in);
      
      /**
       * scheduleList[] array of type Schedule. 
       */
      Schedule scheduleList[] = new Schedule[5];
      
      /**
       * scheduleList[] objects initialize the value for descriptions. Each object is given a unique description.
       * Schedule of tasks is created based on respective subclasses.
       */
      scheduleList[0] = new PerDaySchedule("Oil change.");
      scheduleList[1] = new PerDaySchedule1("Change break fluid.");
      scheduleList[2] = new PerMonthSchedule("Change wheels.");
      scheduleList[3] = new PerMonthSchedule("Check engine vibration.");
      scheduleList[4] = new OnceSchedule("Check hydraulics.");
      
      /**
       * Displays messages to prompt user for date input.
       * User enters date values as integers.
       */
      System.out.println("Enter a date (like 2020 01 30):");
      System.out.print("Please enter a year: ");
      int year = console.nextInt();

      console.nextLine();
      
      System.out.print("Please enter a month: ");
      int month = console.nextInt();
      console.nextLine();
      
      System.out.print("Please enter a day: ");
      int day = console.nextInt();
      console.nextLine();

      System.out.println("Here are your activities scheduled on " + month + "/" + day + "/" + year + ":");
      
      /**	
       * Loops through scheduleList array checking if date arguments input by users match dates specified in each object's dueOn() method's parameter.
       * dueOn() method is executed polymorphically and if dueOn() returns true, meaning there is a match, the program prints out the schedule for that day
       * using the Superclass's toString() method to format the description. Otherwise, the program only prints out the daily schedule.
       */
      for(int i= 0; i < scheduleList.length; i++) {
    	  if((scheduleList[i].dueOn(year, month, day)==true)) {
    		  
    		  System.out.println(scheduleList[i].toString());
    	  }
    	  else {
    		  System.out.println("");
    	  }
      }











   }
}
