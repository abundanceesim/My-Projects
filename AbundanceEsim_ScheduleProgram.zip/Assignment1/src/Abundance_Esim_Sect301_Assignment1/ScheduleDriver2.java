package Abundance_Esim_Sect301_Assignment1;

/**
 * Project: Assignment 1
 * Description: ScheduleDriver2 class containing main method for PerMonthSchedule and OnceSchedule classes. 
 * This class runs a series of tests on Schedule class, PerMonthSchedule and Once Schedule classes.
 * class.
 * @author Abundance Esim
 */
public class ScheduleDriver2 {
	
	public static void main(String[] args) {
		/**
		 * References to classes created. These will be used with Java's reflection API methods to provide information on the various classes.
		 */
		Class schedule = Schedule.class;
		
		Class perMonth = PerMonthSchedule.class;
		Class once = OnceSchedule.class;
		
		/**
		 * Tests performed using Java's reference API. Information is provided about superclass and subclass
		 * Expected outputs and actual outputs are displayed.
		 */
		PerMonthSchedule month1 = new PerMonthSchedule("change wheels");
		OnceSchedule oneTime = new OnceSchedule("check hydraulics");
		
		/**
		 * tests if class PerMonthSchedule is a subclass of class Schedule.
		 */
		System.out.print("PerMonthSchedule is subclass of Schedule: ");
		System.out.println(perMonth.getSuperclass() == schedule);
		System.out.println("Expected: true");
		
		/**
		 * Tests if class OnceSchedule is a subclass of class Schedule.
		 */
		System.out.print("OnceSchedule is subclass of Schedule: ");
		System.out.println(once.getSuperclass() == schedule);
		System.out.println("Expected: true");
		
		/**
		 * Checks for any extra fields in subclass. If the number of declared fields in superclass is equal to or more than the number in subclass,
		 * subclass does not contain any extra fields.
		 */
		System.out.print("PerMonthSchedule have no extra fields: ");
		System.out.println(schedule.getDeclaredFields().length >= perMonth.getDeclaredFields().length);
		System.out.println("Expected: true");
		
		/**
		 * Checks for any extra fields in subclass. If the number of declared fields in superclass is equal to or more than the number in subclass,
		 * subclass does not contain any extra fields.
		 */		
		System.out.print("OnceSchedule scheduled activities have no extra fields: ");
		System.out.println(schedule.getDeclaredFields().length >= once.getDeclaredFields().length);
		System.out.println("Expected: true");
		
		/**
		  * Checks schedule for monthly activities and displays them using PerDaySchedule's dueOn() method. 
		*/
		System.out.print("Looking at per month schedules: ");
		System.out.println(month1.toString());
		System.out.println("Expected: change wheels");
		System.out.println(month1.dueOn(2022, 11, 3));
		System.out.println("Expected: true");
		
		/**
		  * Checks schedule for activities that occur once in a while and displays them using OnceSchedule's dueOn() method. 
		*/
		System.out.print("Looking at OnceSchedule schedules: ");
		System.out.println(oneTime.toString());
		System.out.println("Expected: check hydraulics");
		System.out.println(oneTime.dueOn(2022, 11, 3));
		System.out.println("Expected: false"); 
		
	}
	
	
	
}
