package Abundance_Esim_Sect301_Assignment1;

/**
 * Project: Assignment1
 * Description: This class is a copy of the PerDaySchedule class.
 * @author Abundance Esim
 */
public class PerDaySchedule1 extends Schedule
{
	/**
	 * PerDaySchedule1 constructor with description for daily activities.
	 * @param description the description of the activity.
	 */
   public PerDaySchedule1(String description) {
		super(description);
	}
       
   /**
    * Overridden method for date. Method is run polymorphically for each object of every class in the inheritance hierarchy for superclass Schedule.
    * This method will return true for any date argument in order to provide the description of daily activities.
    */
   @Override
   public Boolean dueOn(int year, int month, int day) {
	   return true;   
   }
}