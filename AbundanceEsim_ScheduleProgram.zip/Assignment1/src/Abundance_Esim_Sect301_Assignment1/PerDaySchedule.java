package Abundance_Esim_Sect301_Assignment1;
/**
   This is code for Part 1.
   In this file, create a subclass named PerDaySchedule. This is 
   a subclass of the Schedule Superclass.
   Schedule has a description (for example,
   "change the gear oil") and happens on one or more dates.
   A perdayschedule activity happens every day.
*/
/**
 * Project: Assignment1
 * Description: PerDaySchedule contains description for activities that happen daily.
 * @author Abundance Esim
 */
public class PerDaySchedule extends Schedule
{
	/**
	 * PerDaySchedule constructor with description for daily activities.
	 * @param description the description of the activity.
	 */
   public PerDaySchedule(String description) {
		super(description);
	}
   
   
   /**
    * Overridden method for date. Method is run polymorphically for each object of every class in the inheritance hierarchy for superclass Schedule.
    * This method will return true for any date argument in order to provide the description of daily activities.
    */
   @Override
   public Boolean dueOn(int year, int month, int day) {
		return true;   
   }
}

