
package Abundance_Esim_Sect301_Assignment1;

/**
 * Project: Assignment 1
 * Description: Schedule class is an abstract classes which contains an abstract method, "dueOn()" which is to be overridden by all concrete subclasses
 * depending on the usage. Class contains template for making concrete subclasses.
 * @author Abundance Esim
 */
public abstract class Schedule
{
private String description;

/**
   Constructs a schedule using a description for a task/activity that is to occur on a certain date.
*/
public Schedule(String description)
{
   setDescription(description);	
}

/**
   Sets the description of this schedule.
   @param description the text description of the schedule
*/
public void setDescription(String description)
{
   this.description = description;
}

/**
   Determines if this scheduled activity happens on the given date.
   @param year the year
   @param month the month
   @param day the day
   @return true if the scheduled activity happens on the given date.
*/
public abstract Boolean dueOn(int year, int month, int day);
/**
   Converts scheduled activity to string description.
   @return formatted description.
*/
public String toString()
{
   return description;
}
}

