package Abundance_Esim_Sect301_Assignment1;

/**
 * Project: Assignment1
 * Description: PerMonthSchedule will instantiate objects with descriptions for tasks that run once every month.
 * @author Abundance Esim
 */
public class PerMonthSchedule extends Schedule
{
	/**
	 * Constructor for PerMonthSchedule with description.
	 * @param description the description of the activity to be carried out.
	 */
   public PerMonthSchedule(String description) {
	   super(description);
   }
   
   /**
    * Overridden method for date. Method is run polymorphically for each object of every class in the inheritance hierarchy for superclass Schedule.
    * If date arguments match condition for date(3rd or 19th day of every month), method will return true, otherwise it will return false.
    */
   @Override
   public Boolean dueOn(int year, int month, int day){
	   if (day==3 || day==19) {
		   return true;
	   }
	   else {
		   return false;
	   }
   } 

}
